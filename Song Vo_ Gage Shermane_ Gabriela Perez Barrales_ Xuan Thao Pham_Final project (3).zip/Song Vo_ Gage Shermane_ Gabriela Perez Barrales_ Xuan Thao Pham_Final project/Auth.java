package finalProject;

import java.util.*;
import java.io.File;
import java.io.*;

public class Auth extends Command1{

	private static FileWriter fw;
	private static BufferedWriter bw;
	
	
	public Auth() throws IOException {
		fw = new FileWriter("src/finalProject/login-info.txt", true);
	
	//src/aa/login-info.txt is the specific text file that was implemented in package aa in src file.
	
	bw = new BufferedWriter(fw);
	
	}
	
	public boolean register(String un, String pwd) throws IOException {

		try {

			Scanner sc = new Scanner(new File("src/finalProject/login-info.txt"));

			while (sc.hasNextLine()) {

				String line = sc.nextLine();

				String user = line.substring(0, line.indexOf(","));

				if (user.equals(un))
					return false;

			}

			bw.append(un + "," + pwd);

			bw.append("\n");

		} catch (Exception e) {

			e.printStackTrace();

		}

		return true;

	}
	
	public boolean login(String un, String pwd) throws IOException {

		try {

			Scanner sc = new Scanner(new File("src/finalProject/login-info.txt"));

			while (sc.hasNextLine()) {

				String line = sc.nextLine();

				String user = line.substring(0, line.indexOf(","));

				String pass = line.substring(line.indexOf(",") + 1);

				if (user.equals(un) && pass.equals(pwd))
					return true;

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		return false;

	}
	
	public static boolean changeUserName(String newUsername, String currentUsername) {
		try {
			projectUtils.modifyFile("src/finalProject/login-info.txt", 
					currentUsername, newUsername );
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean changePassword(String newPw, String currentUsername, String currentPw) {
		try {
			String combinedUsernamePw = currentUsername + "," + currentPw;
			String combinedNewUsernamePw = currentUsername + "," + newPw;
			projectUtils.modifyFile("src/finalProject/login-info.txt", 
					combinedUsernamePw, combinedNewUsernamePw);
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static void printMenu() {
		
		System.out.println("Select: (r)egister or (l)ogin below\n");
		
	}
	
	
	public static void main(String[] args) throws IOException {

		Auth a = new Auth();

		Scanner in = new Scanner(System.in);

		while (true) {

			printMenu();

			String choice = in.nextLine();

			choice = choice.trim().toLowerCase();

			if (choice.equals("r") || choice.equals("register")) {

				System.out.println("\nEnter username: ");

				String un = in.nextLine();

				System.out.println("Enter password: ");

				String pwd = in.nextLine();

				boolean res = a.register(un, pwd);

				if (!res) {

					System.out.println("\nUsername already exists");

				}

			} else if (choice.equals("l") || choice.equals("login")) {

				bw.close();

				System.out.println("\nEnter username: ");

				String un = in.nextLine();

				System.out.println("Enter password: ");

				String pwd = in.nextLine();

				boolean res = a.login(un, pwd);

				if (!res) {
					System.out.println("\nInvalid username or password");
				} else {
					System.out.println("\nSuccessfully logged in. Hi, " + un);
					
					createFolder();
					
					int choiceNum = template(un, pwd);
					if(choiceNum == 3) {
						System.out.println("Please input your new username");
						String newUserName = in.nextLine();
						if(changeUserName(newUserName, un)){
							System.out.println("Sucessfully Updated!");
							un = newUserName;
						}
						template(un, pwd);
						
					}
					else if(choiceNum == 6){
						System.out.println("Please input your new password");
						String newPassword = in.nextLine();
						if(changePassword(newPassword, un, pwd)){
							System.out.println("Sucessfully Updated!");
							pwd = newPassword;
						}
						template(un, pwd);
					}
				}
			}
		}
	}
}


