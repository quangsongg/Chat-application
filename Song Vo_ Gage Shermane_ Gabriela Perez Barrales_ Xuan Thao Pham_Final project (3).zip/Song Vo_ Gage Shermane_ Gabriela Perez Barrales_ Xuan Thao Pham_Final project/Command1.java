package finalProject;

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.BufferedReader;;

class Command1{
	private static String currentUsername;
	private static String currentPassword;
	private static String[] roomName;
	private static String currentName;
	private static boolean isInChat; {isInChat = false;}
	
	public static int template(String loggedUser, String loggedPw) throws IOException{
		currentUsername = loggedUser;
		currentPassword = loggedPw;
		char userChoice;
		Scanner scnr = new Scanner(System.in);
		String room;
				
		System.out.println("Please select from the following options:");
		System.out.println("(J)oin, (C)reate, (A)ccount, (L)ogout");
		System.out.println("-----------------------------------------");
		
		userChoice = scnr.next().charAt(0);
		room = scnr.nextLine();
		room = room.trim();
		//System.out.println(room);
		
		if (userChoice == 'j' || userChoice == 'J')
			join(room);
		else if (userChoice == 'c' || userChoice == 'C')
			create(room);
		else if (userChoice == 'a' || userChoice == 'A') {
			System.out.println("(U) to change username or (P) to change password.");
			char userInput = scnr.next().charAt(0);
			if(userInput == 'u' || userInput == 'U')
				return 3;
			else if (userInput == 'p' || userInput == 'P')
				return 6;
			else {
				System.out.println("Command not found. Please retry.");
				template(currentUsername, currentPassword);	
			}
		}
		else if (userChoice == 'l' || userChoice == 'L')
			logOut();
		else {
			System.out.println("Command not found. Please retry.");
			template(currentUsername, currentPassword);	
		}
		
		return -1;
	}
	
	public static void join(String room) throws IOException{
		String room1 = room + ".txt";
		currentName = room;
		if(roomName == null) {
			System.out.println("Chatroom does not exist. Please try again.");
			template(currentUsername, currentPassword);
		}
		else {
			for(int i = 0; i < roomName.length; i++) {
				//System.out.println(roomName[i] + " " + room1);
				if(room1.equals(roomName[i])) {
					isInChat = true;
					inChat("src\\finalProject\\chatRoom\\" + room1);
					return;
				}
			}
			System.out.println("Chatroom does not exist. Please try again.");
			template(currentUsername, currentPassword);	
		}
		
		return;
	}
	
	public static void create(String room) throws IOException{
		currentName = room;
		String specialCharactersString = "!@#$%&*()'+,-./:;<=>?[]^_`{|}";
        for (int i = 0; i < room.length() ; i++)
        {
            char ch = room.charAt(i);
            if(specialCharactersString.contains(Character.toString(ch))) {
                System.out.println("Cannot contain special characters.");
                template(currentUsername, currentPassword);
                return;
            }
        }
        
        try {
        	String room1 = "src\\finalProject\\chatRoom\\" + room + ".txt";
        	File myFile = new File(room1);
        	if(myFile.createNewFile()) {
                isInChat = true;
        		inChat(room1);
        		return;
        	}
        	else {
        		System.out.println("Cannot create the chatroom. Please try again!");
        		template(currentUsername, currentPassword);
        	}
    	}
        	
    	catch (IOException e){
    		e.printStackTrace();
    	}
        
        return;
	}
	
	public static void createFolder() {
		File folder = new File("src\\finalProject\\chatRoom");
		if (!folder.exists()) {
			folder.mkdir();
		}
		roomName = folder.list();
	}
	
	public static void chatTemplate() {
		System.out.println("Welcome to \"" + currentName + "\", " + currentUsername);
		System.out.println("Please type /help for help.");
		//System.out.println("Type \"stop\" to stop chat"); 
		System.out.println("-----------------------------------------");
	}
	
	public static boolean inChat (String room) throws IOException{
		chatTemplate();
		PrintWriter wr = new PrintWriter(new FileWriter(room));
		Scanner sc = new Scanner(System.in);
		String text;
		
		  while(isInChat) {
			text = sc.nextLine();
			if(text.equals("/help")) {
				help();
			}
			else if(text.equals("/exit")) {
				isInChat = false;
				template(currentUsername, currentPassword);
			}
			else if(text.equals("/list")) {
				System.out.println("Active users in chat room:\n");
				displayUser();
			}
			else if(text.equals("/chat")) {
				wr.close();
				System.out.println("Chat history:\n");
				chatHistory(room);
			}
			else {
			wr.write(currentUsername + ":" + text + "\n");
			System.out.println(currentUsername + ": " + text);
			}
			
		  }
		wr.close();
		template(currentUsername, currentPassword);
		return true;
	}

	public static void logOut() {
		isInChat = false;
		currentUsername = "";
		currentPassword = "";
		currentName = "";
	}
	
	public static void help() {
		System.out.println("\nAvailable commands are: ");
		System.out.println("1. /list (Displays a list of all users in this chat room)");
		System.out.println("2. /exit (Exits this chat room)");
		System.out.println("3. /chat (Displays all past messages from this chat room)");
		System.out.println("4. /help (Lists available commands)");

	}
	
	public static void chatHistory(String room) throws IOException {
		try {
			File file = new File(room);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String line;
			while((line = br.readLine()) != null){
			    //process the line
			    System.out.println(line);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	
	public static void displayUser() {
		System.out.println(currentUsername);
		return;
	}
}
